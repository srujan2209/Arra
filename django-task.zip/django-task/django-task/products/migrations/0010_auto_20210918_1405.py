# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('products', '0009_auto_20150124_2123'),
    ]

    operations = [
        migrations.AlterField(
            model_name='productimage',
            name='image',
            field=models.ImageField(upload_to='product/images/'),
        ),
        migrations.AlterField(
            model_name='variation',
            name='category',
            field=models.CharField(max_length=120, default=('size', 'Size'), choices=[('size', 'Size'), ('color', 'Color'), ('package', 'Package')]),
        ),
    ]
